# Woocommerce-Delivery-Time
Wordpress Woocommerce plugin to set an estimated delivery time for all products
